public class AgaUtils {

    public static String getTextUppercase(String text){
        return text.toUpperCase();
    }

}
