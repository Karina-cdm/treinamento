public class Book {

    private String title = "Today is the day";

    public String getTitle(){
        return AgaUtils.getTextUppercase(title);
    }
}
